Il codice è presente solo con estensione testuale. 
Per l'esecuzione è necessario importare e formattare in Java. 
Simula il funzionamento di un sistema di monitoraggio della temperatura dell'ambiente. 